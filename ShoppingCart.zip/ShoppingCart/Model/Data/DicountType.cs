﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Model.Data
{
    public enum DiscountType
    {
        PercentageDicount,
        BuyOneGetOneFreeDiscount,
        BuyTwoGetOneFreeDiscount
    }
}
