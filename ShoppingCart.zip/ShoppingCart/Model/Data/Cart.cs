﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Model.Data
{
    public class Cart
    {
        public int Id { get; set; }
        public List<Order> Orders { get; set; }
        public double CartTotal { get; set; }
    }
}
