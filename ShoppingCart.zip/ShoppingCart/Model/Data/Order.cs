﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Model.Data
{
    public class Order
    {
        public int Id { get; set; }
        public int TransactionId { get; set; }
        public List<Item> Items { get; set; }
        public DateTime DateOfPurchase { get; set; }
        public double TotalPrice { get; set; }

        public Order()
        {
            Items.ForEach(i =>
            {
                TotalPrice += i.Price * i.Quantity;
                
            });
        }
    }
}
