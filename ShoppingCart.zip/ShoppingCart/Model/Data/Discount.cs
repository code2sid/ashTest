﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Model.Data
{
    public class Discount
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public DiscountType Type { get; set; }
        public double discountPercent { get; set; }
    }
}
