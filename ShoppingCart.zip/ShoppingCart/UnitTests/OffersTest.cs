using Xunit;
using Moq;
using Services.Interfaces;

namespace UnitTests
{
    public class OffersTest
    {
        [Fact]
        public void Offers_getOrders_VerifyMethodExecution()
        {
            //Assert
           var repos = new Mock<IOffersRepository>();
            //Act
            repos.Object.getApplicableOffers();
            //Assert
            repos.Verify(x => x.getApplicableOffers(), Times.Once);
        }
    }
}