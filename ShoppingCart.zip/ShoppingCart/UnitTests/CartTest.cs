using System;
using Xunit;
using Services.DataServices;
using Moq;
using Services.ServiceInterface;

namespace UnitTests
{
    public class CartTest
    {
        [Fact]
        public void Cart_getFinalCart_VerifyMethodExecution()
        {
            //Assert
            var service = new Mock<ICartService>();
            //Act
            service.Object.GetFinalCart(1001);
            //Assert
            service.Verify(x => x.GetFinalCart(1001), Times.Once);
        }
    }
}