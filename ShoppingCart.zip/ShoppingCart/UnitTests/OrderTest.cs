using System;
using System.Collections.Generic;
using Xunit;
using Model.Data;
using Moq;
using Services.Interfaces;

namespace UnitTests
{
    public class OrderTest
    {
        [Fact]
        public void Order_getOrders_VerifyMethodExecution()
        {
            //Assert
            Mock<IOrdersRepository> repos = new Mock<IOrdersRepository>();
            //Act
            repos.Object.getOrders(1001);
            //Assert
            repos.Verify(x => x.getOrders(1001), Times.Once);
        }

        [Fact]
        public void Order_addOrder_VerifyMethodExecution()
        {
            //Assert
            var repos = new Mock<IOrdersRepository>();
            //Act
            var items = new List<Item>
            {
                new Item {Id = 1, Name = "item1", Desciption = "item description", Price = 99.99, Quantity = 2},
                new Item {Id = 2, Name = "item2", Desciption = "item description", Price = 199.99, Quantity = 2}
            };
            repos.Object.addOrder(1001, items);

            //Assert
            repos.Verify(x => x.addOrder(1001, items), Times.Once);
        }
    }
}