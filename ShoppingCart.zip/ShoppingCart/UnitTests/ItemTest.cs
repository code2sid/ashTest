using Xunit;
using Moq;
using Services.Interfaces;

namespace UnitTests
{
    public class ItemTest
    {
        [Fact]
        public void Item_getItems_VerifyMethodExecution()
        {
            //Assert
           var repos = new Mock<IItemRepository>();
            //Act
            repos.Object.getItems();
            //Assert
            repos.Verify(x => x.getItems(), Times.Once);
        }
    }
}