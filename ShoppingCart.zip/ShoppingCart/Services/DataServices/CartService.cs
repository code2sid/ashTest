﻿using System;
using System.Collections.Generic;
using System.Text;
using Services.Interfaces;
using Model.Data;
using Services.ServiceInterface;

namespace Services.DataServices
{
    public class CartService : ICartService
    {
        readonly IOrdersRepository _ordersRepository;
        readonly IOffersRepository _offersRepository;

        public CartService(IOrdersRepository ordersRepository,
            IOffersRepository offersRepository)
        {
            _ordersRepository = ordersRepository;
            _offersRepository = offersRepository;
        }

        public Cart GetFinalCart(int transactionId)
        {
            var orders = _ordersRepository.getOrders(transactionId);
            var offers = _offersRepository.getApplicableOffers();
            return ProcessOrdersWithOffers(orders, offers);
        }

        private static Cart ProcessOrdersWithOffers(List<Order> orders, List<Discount> offers)
        {
            offers.ForEach(offer =>
            {
                switch (offer.Type)
                {
                    case DiscountType.PercentageDicount:
                        orders.ForEach(order =>
                            CalculatePercentageDiscount(order.TotalPrice, offer.discountPercent));
                        break;
                    case DiscountType.BuyOneGetOneFreeDiscount:
                        orders.ForEach(order => CalculateBuy1Get1Discount(orders));
                        break;
                    case DiscountType.BuyTwoGetOneFreeDiscount:
                        orders.ForEach(order => CalculateBuy2Get1Discount(orders));
                        break;
                    default:
                        break;
                }
            });
            var total = 0.0;
            orders.ForEach(o => total += o.TotalPrice);

            return new Cart
            {
                Id = 1010, //return from Db
                Orders = orders,
                CartTotal = total
            };
        }

        private static double CalculatePercentageDiscount(double price, double percentage)
        {
            return (price - (price * percentage / 100));
        }

        private static List<Order> CalculateBuy1Get1Discount(List<Order> orders)
        {
            //implement logic to apply only one price for same price items
            return orders;
        }

        private static List<Order> CalculateBuy2Get1Discount(List<Order> orders)
        {
            //implement logic to apply to give only least price item as free.
            return orders;
        }
    }
}