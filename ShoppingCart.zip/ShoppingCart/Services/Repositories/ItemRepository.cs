﻿using System;
using System.Collections.Generic;
using System.Text;
using Model.Data;
using Services.Interfaces;

namespace Services.Repositories
{
    public class ItemRepository : IItemRepository
    {
        public List<Item> getItems()
        {
            var items = new List<Item>();
            items.Add(new Item { Id = 101, Name = "items 1", Price = 999.99, Quantity=2 });
            items.Add(new Item { Id = 101, Name = "items 2", Price = 499.99, Quantity = 2 });
            items.Add(new Item { Id = 101, Name = "items 3", Price = 299.99, Quantity = 2 });
            items.Add(new Item { Id = 101, Name = "items 4", Price = 399.99, Quantity = 2 });
            items.Add(new Item { Id = 101, Name = "items 5", Price = 599.99, Quantity = 2 });
            items.Add(new Item { Id = 101, Name = "items 6", Price = 699.99, Quantity = 2 });
            items.Add(new Item { Id = 101, Name = "items 7", Price = 799.99, Quantity = 2 });
            items.Add(new Item { Id = 101, Name = "items 8", Price = 899.99, Quantity = 2 });
            items.Add(new Item { Id = 101, Name = "items 9", Price = 1999.99, Quantity = 2 });
            items.Add(new Item { Id = 101, Name = "items 10", Price = 999.99, Quantity = 2 });
            items.Add(new Item { Id = 101, Name = "items 11", Price = 999.99, Quantity = 2 });
            items.Add(new Item { Id = 101, Name = "items 12", Price = 499.99, Quantity = 2 });
            items.Add(new Item { Id = 101, Name = "items 13", Price = 299.99, Quantity = 2 });
            items.Add(new Item { Id = 101, Name = "items 14", Price = 399.99, Quantity = 2 });
            items.Add(new Item { Id = 101, Name = "items 15", Price = 599.99, Quantity = 2 });
            items.Add(new Item { Id = 101, Name = "items 16", Price = 699.99, Quantity = 2 });
            items.Add(new Item { Id = 101, Name = "items 17", Price = 799.99, Quantity = 2 });
            items.Add(new Item { Id = 101, Name = "items 18", Price = 899.99, Quantity = 2 });
            items.Add(new Item { Id = 101, Name = "items 19", Price = 1999.99, Quantity = 2 });
            return items;
        }
    }
}
