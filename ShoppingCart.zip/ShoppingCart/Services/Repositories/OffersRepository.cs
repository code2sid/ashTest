﻿using System;
using System.Collections.Generic;
using System.Text;
using Model.Data;
using Services.Interfaces;

namespace Services.Repositories
{
    class OffersRepository : IOffersRepository
    {
        public List<Discount> getApplicableOffers()
        {
            throw new NotImplementedException();
        }
    }
}
