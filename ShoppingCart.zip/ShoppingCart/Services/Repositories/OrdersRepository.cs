﻿using System;
using System.Collections.Generic;
using System.Text;
using Model.Data;
using Services.Interfaces;

namespace Services.Repositories
{
    public class OrdersRepository : IOrdersRepository
    {
        public List<Order> getOrders(int transactionId)
        {
            var orders = new List<Order>();
            orders.Add(new Order
            {
                Id = 1001,
                Items = null,
                DateOfPurchase = DateTime.Today,
                TotalPrice = 5999.00,
                TransactionId = 1
            });

            return orders;
        }

        public bool addOrder(int transactionId, List<Item> items)
        {
            throw new NotImplementedException();
        }



    }
}
