﻿using System;
using System.Collections.Generic;
using System.Text;
using Model.Data;

namespace Services.Interfaces
{
    public interface IOrdersRepository
    {
        List<Order> getOrders(int transactionId);
        bool addOrder(int transactionId, List<Item> items);
    }
}
