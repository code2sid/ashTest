﻿using System;
using System.Collections.Generic;
using System.Text;
using Model.Data;

namespace Services.Interfaces
{
   public interface IItemRepository
    {
        List<Item> getItems();
    }
}
