using Model.Data;

namespace Services.ServiceInterface
{
    public interface ICartService
    {
        Cart GetFinalCart(int transactionId);

    }
}