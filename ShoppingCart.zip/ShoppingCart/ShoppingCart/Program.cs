﻿using System;

namespace ShoppingCart
{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
