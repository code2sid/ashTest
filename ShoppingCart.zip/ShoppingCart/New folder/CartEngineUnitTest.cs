﻿using AshSoft.Cart.RuleEngine.Contract;
using Moq;
using Xunit;
using Model = AshSoft.Cart.RuleEngine.DomainModel;

namespace AshSoft.Cart.RuleEngine.Test
{
    public class CartEngineUnitTest
    {
        [Fact]
        public void CartEngine_CalculateCartTotal_VerifyMethodExecution()
        {
            //Assert
            Mock<ICartEngine> discount = new Mock<ICartEngine>();
            var cart = new Model.Cart();
            //Act
            discount.Object.CalculateTotal(cart, Model.DiscountType.BuyTwoGetOneFreeDiscount);
            //Assert
            discount.Verify(x => x.CalculateTotal(cart, Model.DiscountType.BuyTwoGetOneFreeDiscount), Times.Once);
        }
    }
}
