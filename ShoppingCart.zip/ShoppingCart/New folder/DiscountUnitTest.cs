using AshSoft.Cart.RuleEngine.Contract;
using Moq;
using Xunit;
using Model = AshSoft.Cart.RuleEngine.DomainModel;

namespace AshSoft.Cart.RuleEngine.Test
{
    public class DiscountUnitTest
    {
        [Fact]
        public void Discount_ApplyDiscount_VerifyMethodExecution()
        {
            //Assert
            Mock<IDiscount> discount = new Mock<IDiscount>();
            var cart = new Model.Cart();
            //Act
            discount.Object.ApplyDiscount(cart);
            //Assert
            discount.Verify(x => x.ApplyDiscount(cart), Times.Once);
        }
    }
}
