using NUnit.Framework;

namespace Tests
{
    [TestFixture]
    public class CartTest
    {
        [Fact]
        public void CartEngine_CalculateCartTotal_VerifyMethodExecution()
        {
            //Assert
            Mock<ICartEngine> discount = new Mock<ICartEngine>();
            var cart = new Model.Cart();
            //Act
            discount.Object.CalculateTotal(cart, Model.DiscountType.BuyTwoGetOneFreeDiscount);
            //Assert
            discount.Verify(x => x.CalculateTotal(cart, Model.DiscountType.BuyTwoGetOneFreeDiscount), Times.Once);
        }
    }
}