﻿using AshSoft.Cart.RuleEngine.Contract;
using Moq;
using Xunit;
using Model = AshSoft.Cart.RuleEngine.DomainModel;

namespace AshSoft.Cart.RuleEngine.Test
{
    public class DiscountFactoryUnitTest
    {
        [Fact]
        public void DiscountFactory_Create_VerifyMethodExecution()
        {
            //Assert
            Mock<IDiscountFactory> discount = new Mock<IDiscountFactory>();
            //Act
            discount.Object.Create(Model.DiscountType.BuyTwoGetOneFreeDiscount);
            //Assert
            discount.Verify(x => x.Create(Model.DiscountType.BuyTwoGetOneFreeDiscount), Times.Once);
        }
    }
}
