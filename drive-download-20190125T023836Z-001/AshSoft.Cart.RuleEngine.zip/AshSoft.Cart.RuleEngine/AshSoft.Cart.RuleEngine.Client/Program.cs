﻿using System;

namespace AshSoft.Cart.RuleEngine.Client
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
