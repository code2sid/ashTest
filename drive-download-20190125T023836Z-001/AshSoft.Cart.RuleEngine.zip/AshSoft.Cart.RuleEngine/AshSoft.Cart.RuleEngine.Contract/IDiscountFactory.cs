﻿using AshSoft.Cart.RuleEngine.DomainModel;

namespace AshSoft.Cart.RuleEngine.Contract
{
    public interface IDiscountFactory
    {
        IDiscount Create(DiscountType discountType);
    }
}
