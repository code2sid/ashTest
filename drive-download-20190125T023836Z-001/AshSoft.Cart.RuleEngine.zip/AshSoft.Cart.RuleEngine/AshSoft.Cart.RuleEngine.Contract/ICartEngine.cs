﻿using Model = AshSoft.Cart.RuleEngine.DomainModel;
namespace AshSoft.Cart.RuleEngine.Contract
{
    public interface ICartEngine
    {
        Model.Cart CalculateTotal(Model.Cart cart, Model.DiscountType discountType);
    }
}
