﻿using Model = AshSoft.Cart.RuleEngine.DomainModel;
namespace AshSoft.Cart.RuleEngine.Contract
{
    //Implement strategy design pattern
    public interface IDiscount
    {
        decimal ApplyDiscount(Model.Cart cart);
    }
}
