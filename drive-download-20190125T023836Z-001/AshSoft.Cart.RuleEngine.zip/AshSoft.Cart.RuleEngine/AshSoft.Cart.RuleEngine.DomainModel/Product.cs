﻿using System;

namespace AshSoft.Cart.RuleEngine.DomainModel
{
    public class Product
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
        public DateTime DateOfManu { get; set; }
        public DateTime DateOfExpiry { get; set; }
    }
}
