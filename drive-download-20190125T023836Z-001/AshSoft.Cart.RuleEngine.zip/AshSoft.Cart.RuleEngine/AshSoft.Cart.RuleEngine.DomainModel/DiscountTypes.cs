﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AshSoft.Cart.RuleEngine.DomainModel
{
    public enum DiscountType
    {
        BuyTwoGetOneFreeDiscount,
        BuyTwoGetOneFreeCombinationDiscount,
    }
}
