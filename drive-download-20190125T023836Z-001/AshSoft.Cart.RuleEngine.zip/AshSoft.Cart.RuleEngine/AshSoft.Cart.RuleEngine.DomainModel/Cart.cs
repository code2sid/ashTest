﻿using System.Collections.Generic;

namespace AshSoft.Cart.RuleEngine.DomainModel
{
    public class Cart
    {
        public int Id { get; set; }
        public IList<ProductOrder> Orders { get; set; }
        public decimal Total { get; set; }
    }
}
