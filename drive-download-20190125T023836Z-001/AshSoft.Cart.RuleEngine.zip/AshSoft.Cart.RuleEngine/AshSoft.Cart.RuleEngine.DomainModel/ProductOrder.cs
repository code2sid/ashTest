﻿namespace AshSoft.Cart.RuleEngine.DomainModel
{
    public class ProductOrder
    {
        public Product Product { get; set; }
        public int Quantity { get; set; }
    }
}
