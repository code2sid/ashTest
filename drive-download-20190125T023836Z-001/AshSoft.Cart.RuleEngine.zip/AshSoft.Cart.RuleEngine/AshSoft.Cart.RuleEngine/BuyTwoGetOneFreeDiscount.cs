﻿using AshSoft.Cart.RuleEngine.Contract;
using Model = AshSoft.Cart.RuleEngine.DomainModel;
using System.Linq;

namespace AshSoft.Cart.RuleEngine
{
    //This class rule is to calculate discount on total cart 
    public class BuyTwoGetOneFreeDiscount : IDiscount
    {
        public decimal ApplyDiscount(Model.Cart cart)
        {
            decimal discount = 0;
            var orders = cart.Orders.Where(x => x.Quantity > 2);
            foreach (var order in orders)
            {
                discount += order.Product.Price * order.Quantity / 3;
            }
            return discount;
        }
    }
}
