﻿using AshSoft.Cart.RuleEngine.Contract;
using AshSoft.Cart.RuleEngine.DomainModel;

namespace AshSoft.Cart.RuleEngine
{
    class NoDiscount : IDiscount
    {
        public decimal ApplyDiscount(DomainModel.Cart cart)
        {
            return 0;
        }
    }
}