﻿using AshSoft.Cart.RuleEngine.Contract;
using AshSoft.Cart.RuleEngine.DomainModel;

namespace AshSoft.Cart.RuleEngine
{
    //Simple factory design pattern to create discount types
    public class DiscountFactory
    {
        //Consumed by client
        public IDiscount Create(DiscountType discountType)
        {
            switch (discountType)
            {
                case DiscountType.BuyTwoGetOneFreeDiscount:
                    return new BuyTwoGetOneFreeDiscount();
                case DiscountType.BuyTwoGetOneFreeCombinationDiscount:
                    return new BuyTwoGetOneFreeCombinationDiscount();
                default: return new NoDiscount();
            }
        }
    }
}
