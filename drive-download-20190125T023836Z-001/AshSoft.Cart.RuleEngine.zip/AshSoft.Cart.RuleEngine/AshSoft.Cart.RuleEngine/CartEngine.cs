﻿using AshSoft.Cart.RuleEngine.Contract;
using Model = AshSoft.Cart.RuleEngine.DomainModel;
using System.Linq;
namespace AshSoft.Cart.RuleEngine
{
    public class CartEngine: ICartEngine
    {
        private readonly IDiscountFactory _discountFactory;
        
        //Factory DI implemened
        public CartEngine(IDiscountFactory discountFactory)
        {
            _discountFactory = discountFactory;
        }

        public Model.Cart CalculateTotal(Model.Cart cart, Model.DiscountType discountType)
        {
            decimal total = CalculateTotalBeforeDiscount(cart);
            cart.Total = total - _discountFactory.Create(discountType).ApplyDiscount(cart);
            return cart;
        }

        private decimal CalculateTotalBeforeDiscount(Model.Cart cart)
        {
            return cart.Orders.Sum(x => x.Quantity * x.Product.Price);
        }
    }
}
